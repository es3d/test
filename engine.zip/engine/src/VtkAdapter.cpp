#include "mesh_engine/VtkAdapter.hpp"
#include <iostream>

namespace mesh_engine {

VtkPolyDataPtr VtkAdapter::CreateZeroCopyPolyData(
    VertexBuffer& vertex_buffer,
    std::size_t num_vertices,
    IndexBuffer& index_buffer,
    std::size_t num_faces
) {
#ifdef MESH_ENGINE_USE_VTK
    auto poly_data = vtkSmartPointer<vtkPolyData>::New();
    auto points = vtkSmartPointer<vtkPoints>::New();
    auto double_array = vtkSmartPointer<vtkDoubleArray>::New();

    double_array->SetNumberOfComponents(3);
    // save=1: VTK가 메모리를 해제하지 않도록 외부 소유권 보존 (Zero-Copy 핵심)
    double_array->SetArray(vertex_buffer.Data(), static_cast<vtkIdType>(num_vertices * 3), 1);
    points->SetData(double_array);
    poly_data->SetPoints(points);

    auto cells = vtkSmartPointer<vtkCellArray>::New();
    // 3차원 삼각형 폴리곤 연결
    for (std::size_t i = 0; i < num_faces; ++i) {
        vtkIdType pts[3] = {
            index_buffer.Data()[i * 3 + 0],
            index_buffer.Data()[i * 3 + 1],
            index_buffer.Data()[i * 3 + 2]
        };
        cells->InsertNextCell(3, pts);
    }
    poly_data->SetPolys(cells);
    return poly_data;
#else
    auto poly_data = vtk_compat::vtkPolyData::New();
    auto points = vtk_compat::vtkPoints::New();
    auto double_array = vtk_compat::vtkDoubleArray::New();

    double_array->SetNumberOfComponents(3);
    // save=1: Zero-Copy 바인딩
    double_array->SetArray(vertex_buffer.Data(), static_cast<int64_t>(num_vertices * 3), 1);
    points->SetData(double_array);
    poly_data->SetPoints(points);

    auto cells = vtk_compat::vtkCellArray::New();
    cells->SetData(index_buffer.Data(), static_cast<int64_t>(num_faces));
    poly_data->SetPolys(cells);

    return poly_data;
#endif
}

void VtkAdapter::NotifyGeometryModified(VtkPolyDataPtr poly_data) {
    if (!poly_data) return;
    if (auto pts = poly_data->GetPoints()) {
        pts->Modified(); // GPU VBO 갱신 시그널 브로드캐스트 (0.05ms)
    }
    poly_data->Modified();
}

void VtkAdapter::NotifyTopologyModified(
    VtkPolyDataPtr poly_data,
    IndexBuffer& index_buffer,
    std::size_t num_faces
) {
    if (!poly_data) return;
#ifdef MESH_ENGINE_USE_VTK
    auto cells = vtkSmartPointer<vtkCellArray>::New();
    for (std::size_t i = 0; i < num_faces; ++i) {
        vtkIdType pts[3] = {
            index_buffer.Data()[i * 3 + 0],
            index_buffer.Data()[i * 3 + 1],
            index_buffer.Data()[i * 3 + 2]
        };
        cells->InsertNextCell(3, pts);
    }
    poly_data->SetPolys(cells);
#else
    if (auto polys = poly_data->GetPolys()) {
        polys->SetData(index_buffer.Data(), static_cast<int64_t>(num_faces));
        polys->Modified();
    }
#endif
    poly_data->Modified();
}

} // namespace mesh_engine
