#include "mesh_engine/VersionRouter.hpp"
#include <iostream>

namespace mesh_engine {

void VersionRouter::RegisterHandler(std::shared_ptr<IApiVersionHandler> handler) {
    if (handler) {
        handlers_[handler->GetMajorVersion()] = handler;
    }
}

bool VersionRouter::SupportsVersion(uint16_t major_version) const {
    return handlers_.find(major_version) != handlers_.end();
}

std::vector<uint16_t> VersionRouter::GetSupportedVersions() const {
    std::vector<uint16_t> versions;
    for (const auto& [ver, _] : handlers_) {
        versions.push_back(ver);
    }
    return versions;
}

IpcResponse VersionRouter::Dispatch(const IpcHeader& header, const uint8_t* payload, UnifiedMesh& mesh) {
    // 1. 매직 넘버 검증
    if (header.magic != MESH_IPC_MAGIC) {
        return IpcResponse{ERR_INVALID_MAGIC, 0, "Invalid IPC Header Magic", {}};
    }

    // 2. 메이저 버전 핸들러 검색
    auto it = handlers_.find(header.api_version);
    if (it == handlers_.end()) {
        std::string err_msg = "API Version " + std::to_string(header.api_version) + " is not supported by this engine runtime.";
        return IpcResponse{ERR_UNSUPPORTED_VERSION, 0, err_msg, {}};
    }

    // 3. 해당 버전 격리 어댑터로 실행 위임
    return it->second->HandleCommand(header, payload, mesh);
}

} // namespace mesh_engine
