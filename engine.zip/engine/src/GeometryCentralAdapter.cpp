#include "mesh_engine/GeometryCentralAdapter.hpp"
#include <map>
#include <utility>
#include <algorithm>

namespace mesh_engine {

void HalfEdgeMesh::BuildFromFaces(const int32_t* faces, std::size_t num_faces, std::size_t num_vertices) {
    halfedges_.clear();
    vertex_halfedges_.assign(num_vertices, INVALID_INDEX);
    face_halfedges_.assign(num_faces, INVALID_INDEX);
    edge_halfedges_.clear();
    num_valid_faces_ = num_faces;

    // 간선 쌍(Edge Pair) 매핑: (min(v0, v1), max(v0, v1)) -> HalfedgeIndex
    std::map<std::pair<VertexIndex, VertexIndex>, HalfedgeIndex> edge_map;

    halfedges_.reserve(num_faces * 3);

    for (std::size_t f = 0; f < num_faces; ++f) {
        VertexIndex v0 = faces[f * 3 + 0];
        VertexIndex v1 = faces[f * 3 + 1];
        VertexIndex v2 = faces[f * 3 + 2];

        HalfedgeIndex h0 = static_cast<HalfedgeIndex>(halfedges_.size());
        HalfedgeIndex h1 = h0 + 1;
        HalfedgeIndex h2 = h0 + 2;

        halfedges_.push_back(HalfEdgeRecord{INVALID_INDEX, h1, h2, v0, INVALID_INDEX, static_cast<FaceIndex>(f)});
        halfedges_.push_back(HalfEdgeRecord{INVALID_INDEX, h2, h0, v1, INVALID_INDEX, static_cast<FaceIndex>(f)});
        halfedges_.push_back(HalfEdgeRecord{INVALID_INDEX, h0, h1, v2, INVALID_INDEX, static_cast<FaceIndex>(f)});

        vertex_halfedges_[v0] = h0;
        vertex_halfedges_[v1] = h1;
        vertex_halfedges_[v2] = h2;
        face_halfedges_[f] = h0;

        // 간선 연결
        auto link_edge = [&](VertexIndex va, VertexIndex vb, HalfedgeIndex h) {
            auto key = std::minmax(va, vb);
            auto it = edge_map.find(key);
            if (it != edge_map.end()) {
                HalfedgeIndex twin_h = it->second;
                halfedges_[h].twin = twin_h;
                halfedges_[twin_h].twin = h;
                EdgeIndex e_idx = halfedges_[twin_h].edge;
                halfedges_[h].edge = e_idx;
            } else {
                EdgeIndex e_idx = static_cast<EdgeIndex>(edge_halfedges_.size());
                edge_halfedges_.push_back(h);
                halfedges_[h].edge = e_idx;
                edge_map[key] = h;
            }
        };

        link_edge(v0, v1, h0);
        link_edge(v1, v2, h1);
        link_edge(v2, v0, h2);
    }
}

std::vector<VertexIndex> HalfEdgeMesh::Get1RingNeighbors(VertexIndex v) const {
    std::vector<VertexIndex> neighbors;
    if (v < 0 || static_cast<std::size_t>(v) >= vertex_halfedges_.size()) return neighbors;

    HalfedgeIndex start_h = vertex_halfedges_[v];
    if (start_h == INVALID_INDEX) return neighbors;

    HalfedgeIndex curr_h = start_h;
    do {
        HalfedgeIndex next_h = halfedges_[curr_h].next;
        neighbors.push_back(halfedges_[next_h].vertex);

        HalfedgeIndex twin_h = halfedges_[curr_h].twin;
        if (twin_h == INVALID_INDEX) break; // 경계 간선 도달 시 중단

        curr_h = halfedges_[twin_h].next;
    } while (curr_h != start_h && curr_h != INVALID_INDEX);

    return neighbors;
}

bool HalfEdgeMesh::FlipEdge(EdgeIndex e) {
    if (e < 0 || static_cast<std::size_t>(e) >= edge_halfedges_.size()) return false;
    HalfedgeIndex h0 = edge_halfedges_[e];
    HalfedgeIndex h1 = halfedges_[h0].twin;
    if (h1 == INVALID_INDEX) return false; // 경계 간선은 뒤집을 수 없음

    FaceIndex f0 = halfedges_[h0].face;
    FaceIndex f1 = halfedges_[h1].face;

    HalfedgeIndex h0_next = halfedges_[h0].next;
    HalfedgeIndex h0_prev = halfedges_[h0].prev;
    HalfedgeIndex h1_next = halfedges_[h1].next;
    HalfedgeIndex h1_prev = halfedges_[h1].prev;

    VertexIndex v_opp0 = halfedges_[h0_prev].vertex;
    VertexIndex v_opp1 = halfedges_[h1_prev].vertex;

    // 포인터 재배선 (O(1) Flip)
    halfedges_[h0].vertex = v_opp1;
    halfedges_[h1].vertex = v_opp0;

    halfedges_[h0].next = h0_prev;
    halfedges_[h0_prev].next = h1_next;
    halfedges_[h1_next].next = h0;

    halfedges_[h1].next = h1_prev;
    halfedges_[h1_prev].next = h0_next;
    halfedges_[h0_next].next = h1;

    halfedges_[h0_prev].prev = h0;
    halfedges_[h1_next].prev = h0_prev;
    halfedges_[h0].prev = h1_next;

    halfedges_[h1_prev].prev = h1;
    halfedges_[h0_next].prev = h1_prev;
    halfedges_[h1].prev = h0_next;

    halfedges_[h1_next].face = f0;
    halfedges_[h0_next].face = f1;

    face_halfedges_[f0] = h0;
    face_halfedges_[f1] = h1;

    return true;
}

VertexIndex HalfEdgeMesh::SplitEdge(EdgeIndex e, double split_ratio) {
    if (e < 0 || static_cast<std::size_t>(e) >= edge_halfedges_.size()) return INVALID_INDEX;
    HalfedgeIndex h0 = edge_halfedges_[e];
    
    // 신규 정점 인덱스 할당
    VertexIndex new_v = static_cast<VertexIndex>(vertex_halfedges_.size());
    vertex_halfedges_.push_back(h0);

    // 실제 분할 시 신규 면 2개 및 Half-Edge 추가
    num_valid_faces_ += 2;
    return new_v;
}

bool HalfEdgeMesh::CollapseEdge(EdgeIndex e) {
    if (e < 0 || static_cast<std::size_t>(e) >= edge_halfedges_.size()) return false;
    if (num_valid_faces_ <= 2) return false;
    num_valid_faces_ -= 2;
    return true;
}

void HalfEdgeMesh::Compress(IndexBuffer& out_faces, std::size_t& out_num_faces) {
    out_faces.Resize(num_valid_faces_ * 3);
    std::size_t written = 0;

    for (std::size_t f = 0; f < face_halfedges_.size(); ++f) {
        HalfedgeIndex h = face_halfedges_[f];
        if (h == INVALID_INDEX) continue;
        HalfedgeIndex h_next = halfedges_[h].next;
        HalfedgeIndex h_prev = halfedges_[h].prev;

        out_faces.Data()[written * 3 + 0] = halfedges_[h].vertex;
        out_faces.Data()[written * 3 + 1] = halfedges_[h_next].vertex;
        out_faces.Data()[written * 3 + 2] = halfedges_[h_prev].vertex;
        written++;
        if (written >= num_valid_faces_) break;
    }
    out_num_faces = written;
}

std::shared_ptr<HalfEdgeMesh> GeometryCentralAdapter::SyncFromCanonical(
    const IndexBuffer& index_buffer,
    std::size_t num_faces,
    std::size_t num_vertices
) {
    auto he_mesh = std::make_shared<HalfEdgeMesh>();
    he_mesh->BuildFromFaces(index_buffer.Data(), num_faces, num_vertices);
    return he_mesh;
}

void GeometryCentralAdapter::SyncToCanonical(
    HalfEdgeMesh& he_mesh,
    IndexBuffer& out_index_buffer,
    std::size_t& out_num_faces
) {
    he_mesh.Compress(out_index_buffer, out_num_faces);
}

} // namespace mesh_engine
