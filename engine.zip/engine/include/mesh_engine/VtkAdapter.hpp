#pragma once

#include "BufferPool.hpp"
#include "DirtyState.hpp"
#include <memory>
#include <iostream>
#include <cstdint>

#ifdef MESH_ENGINE_USE_VTK
#include <vtkSmartPointer.h>
#include <vtkPolyData.h>
#include <vtkPoints.h>
#include <vtkDoubleArray.h>
#include <vtkCellArray.h>
#else
// VTK가 아직 링크되지 않은 환경에서도 Zero-Copy 메모리 바인딩 원리를
// 완벽히 실증하고 단위 테스트할 수 있도록 호환 인터페이스를 제공합니다.
namespace vtk_compat {

class vtkDoubleArray {
public:
    static std::shared_ptr<vtkDoubleArray> New() {
        return std::make_shared<vtkDoubleArray>();
    }

    // save=1: VTK 파이프라인이 버퍼의 소유권을 갖지 않고 외부 버퍼를 직접 참조
    void SetArray(double* array, int64_t size, int save, int deleteMethod = 0) {
        raw_ptr_ = array;
        size_ = size;
        save_flag_ = save;
    }

    void SetNumberOfComponents(int components) { components_ = components; }
    [[nodiscard]] double* GetPointer(int64_t id) const { return raw_ptr_ + id; }
    [[nodiscard]] void* GetVoidPointer(int64_t id) const { return static_cast<void*>(raw_ptr_ + id); }
    [[nodiscard]] int64_t GetNumberOfTuples() const { return components_ > 0 ? size_ / components_ : 0; }
    [[nodiscard]] int GetSaveFlag() const { return save_flag_; }
    void Modified() { modified_count_++; }
    [[nodiscard]] uint64_t GetMTime() const { return modified_count_; }

private:
    double* raw_ptr_ = nullptr;
    int64_t size_ = 0;
    int save_flag_ = 0;
    int components_ = 3;
    uint64_t modified_count_ = 1;
};

class vtkPoints {
public:
    static std::shared_ptr<vtkPoints> New() {
        return std::make_shared<vtkPoints>();
    }

    void SetData(std::shared_ptr<vtkDoubleArray> data) { data_array_ = data; }
    [[nodiscard]] std::shared_ptr<vtkDoubleArray> GetData() const { return data_array_; }
    [[nodiscard]] void* GetVoidPointer(int64_t id) const { 
        return data_array_ ? data_array_->GetVoidPointer(id) : nullptr; 
    }
    [[nodiscard]] int64_t GetNumberOfPoints() const {
        return data_array_ ? data_array_->GetNumberOfTuples() : 0;
    }
    void Modified() { 
        if (data_array_) data_array_->Modified(); 
        modified_count_++;
    }
    [[nodiscard]] uint64_t GetMTime() const { return modified_count_; }

private:
    std::shared_ptr<vtkDoubleArray> data_array_;
    uint64_t modified_count_ = 1;
};

class vtkCellArray {
public:
    static std::shared_ptr<vtkCellArray> New() {
        return std::make_shared<vtkCellArray>();
    }

    void SetData(int32_t* connectivity, int64_t num_cells) {
        connectivity_ptr_ = connectivity;
        num_cells_ = num_cells;
    }

    [[nodiscard]] int64_t GetNumberOfCells() const { return num_cells_; }
    [[nodiscard]] int32_t* GetConnectivityPointer() const { return connectivity_ptr_; }
    void Modified() { modified_count_++; }

private:
    int32_t* connectivity_ptr_ = nullptr;
    int64_t num_cells_ = 0;
    uint64_t modified_count_ = 1;
};

class vtkPolyData {
public:
    static std::shared_ptr<vtkPolyData> New() {
        return std::make_shared<vtkPolyData>();
    }

    void SetPoints(std::shared_ptr<vtkPoints> pts) { points_ = pts; }
    [[nodiscard]] std::shared_ptr<vtkPoints> GetPoints() const { return points_; }
    void SetPolys(std::shared_ptr<vtkCellArray> polys) { polys_ = polys; }
    [[nodiscard]] std::shared_ptr<vtkCellArray> GetPolys() const { return polys_; }
    
    void Modified() {
        if (points_) points_->Modified();
        if (polys_) polys_->Modified();
        mtime_++;
    }
    [[nodiscard]] uint64_t GetMTime() const { return mtime_; }

private:
    std::shared_ptr<vtkPoints> points_;
    std::shared_ptr<vtkCellArray> polys_;
    uint64_t mtime_ = 1;
};

} // namespace vtk_compat
#endif

namespace mesh_engine {

#ifdef MESH_ENGINE_USE_VTK
using VtkPolyDataPtr = vtkSmartPointer<vtkPolyData>;
using VtkPointsPtr   = vtkSmartPointer<vtkPoints>;
using VtkDoubleArrayPtr = vtkSmartPointer<vtkDoubleArray>;
using VtkCellArrayPtr = vtkSmartPointer<vtkCellArray>;
#else
using VtkPolyDataPtr = std::shared_ptr<vtk_compat::vtkPolyData>;
using VtkPointsPtr   = std::shared_ptr<vtk_compat::vtkPoints>;
using VtkDoubleArrayPtr = std::shared_ptr<vtk_compat::vtkDoubleArray>;
using VtkCellArrayPtr = std::shared_ptr<vtk_compat::vtkCellArray>;
#endif

/**
 * @brief Zero-Copy VTK 어댑터
 * 
 * Canonical 정규 버퍼의 메모리 포인터를 vtkPoints에 직접 주입(save=1)하여
 * CPU 메모리 복사 없이 VTK 렌더링 파이프라인 및 GPU VBO와 연동합니다.
 */
class VtkAdapter {
public:
    VtkAdapter() = default;

    /**
     * @brief 정규 버퍼를 참조하는 vtkPolyData 객체 생성 (Zero-Copy)
     * 
     * @param vertex_buffer 정점 연속 버퍼 [x0, y0, z0, x1, y1, z1, ...]
     * @param num_vertices 정점 수 (N)
     * @param index_buffer 삼각형 인덱스 버퍼 [v0, v1, v2, ...]
     * @param num_faces 면 수 (M)
     */
    VtkPolyDataPtr CreateZeroCopyPolyData(
        VertexBuffer& vertex_buffer,
        std::size_t num_vertices,
        IndexBuffer& index_buffer,
        std::size_t num_faces
    );

    /**
     * @brief 정점 위치만 변경되었을 때의 고속 동기화 (0.05ms)
     * 
     * 위상 재할당 없이 vtkPoints의 Modified()만 호출하여 GPU VBO를 갱신합니다.
     */
    void NotifyGeometryModified(VtkPolyDataPtr poly_data);

    /**
     * @brief 위상이 변경되었을 때 CellArray 재매핑 동기화
     */
    void NotifyTopologyModified(
        VtkPolyDataPtr poly_data,
        IndexBuffer& index_buffer,
        std::size_t num_faces
    );
};

} // namespace mesh_engine
