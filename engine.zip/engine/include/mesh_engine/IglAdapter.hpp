#pragma once

#include "BufferPool.hpp"
#include <cstdint>

#ifdef MESH_ENGINE_USE_EIGEN
#include <Eigen/Core>
#endif

namespace mesh_engine {

/**
 * @brief libigl 및 Eigen 호환 Zero-Copy 어댑터
 * 
 * 정규 연속 버퍼(Row-Major)의 메모리 포인터를 Eigen::Map으로 래핑하여
 * 복사 비용 없이 libigl의 ARAP, Geodesic, Curvature 등의 수치 알고리즘을 즉시 호출합니다.
 */
class IglAdapter {
public:
    IglAdapter() = default;

#ifdef MESH_ENGINE_USE_EIGEN
    using RowMatrixXd = Eigen::Matrix<double, Eigen::Dynamic, 3, Eigen::RowMajor>;
    using RowMatrixXi = Eigen::Matrix<int32_t, Eigen::Dynamic, 3, Eigen::RowMajor>;

    using ConstVertexMap = Eigen::Map<const RowMatrixXd>;
    using MutableVertexMap = Eigen::Map<RowMatrixXd>;
    using ConstFaceMap   = Eigen::Map<const RowMatrixXi>;
    using MutableFaceMap = Eigen::Map<RowMatrixXi>;

    static ConstVertexMap GetVertexMapView(const VertexBuffer& vb, std::size_t num_vertices) {
        return ConstVertexMap(vb.Data(), static_cast<Eigen::Index>(num_vertices), 3);
    }

    static MutableVertexMap GetMutableVertexMapView(VertexBuffer& vb, std::size_t num_vertices) {
        return MutableVertexMap(vb.Data(), static_cast<Eigen::Index>(num_vertices), 3);
    }

    static ConstFaceMap GetFaceMapView(const IndexBuffer& ib, std::size_t num_faces) {
        return ConstFaceMap(ib.Data(), static_cast<Eigen::Index>(num_faces), 3);
    }
#endif

    // Eigen 없이도 메모리 뷰를 안전하게 조회 가능한 헬퍼
    static const double* GetRawVertexPtr(const VertexBuffer& vb) noexcept { return vb.Data(); }
    static double* GetMutableRawVertexPtr(VertexBuffer& vb) noexcept { return vb.Data(); }
    static const int32_t* GetRawFacePtr(const IndexBuffer& ib) noexcept { return ib.Data(); }
};

} // namespace mesh_engine
