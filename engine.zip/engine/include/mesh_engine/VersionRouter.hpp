#pragma once

#include "IpcProtocol.hpp"
#include "UnifiedMesh.hpp"
#include <memory>
#include <map>
#include <string>
#include <vector>

namespace mesh_engine {

/**
 * @brief IPC 응답 패킷 구조체
 */
struct IpcResponse {
    int32_t status_code = ERR_SUCCESS;
    uint32_t warning_flags = 0; // Deprecation 알림 등
    std::string message;
    std::vector<uint8_t> payload;
};

/**
 * @brief 버전별 핸들러 추상 인터페이스
 */
class IApiVersionHandler {
public:
    virtual ~IApiVersionHandler() = default;
    [[nodiscard]] virtual uint16_t GetMajorVersion() const noexcept = 0;
    virtual IpcResponse HandleCommand(const IpcHeader& header, const uint8_t* payload, UnifiedMesh& mesh) = 0;
};

/**
 * @brief 다중 버전 동적 디스패치 라우터 (Version Router)
 * 
 * 구버전(v1)과 신버전(v2/v3) 클라이언트 요청을 단일 엔진에서 동시에 수용하고,
 * 각 버전 어댑터로 안전하게 분기 라우팅합니다.
 */
class VersionRouter {
public:
    VersionRouter() = default;

    void RegisterHandler(std::shared_ptr<IApiVersionHandler> handler);
    IpcResponse Dispatch(const IpcHeader& header, const uint8_t* payload, UnifiedMesh& mesh);

    [[nodiscard]] bool SupportsVersion(uint16_t major_version) const;
    [[nodiscard]] std::vector<uint16_t> GetSupportedVersions() const;

private:
    std::map<uint16_t, std::shared_ptr<IApiVersionHandler>> handlers_;
};

} // namespace mesh_engine
