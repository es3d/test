#pragma once

#include "BufferPool.hpp"
#include "DirtyState.hpp"
#include <vector>
#include <memory>
#include <cstdint>
#include <cassert>
#include <iostream>

namespace mesh_engine {

/**
 * @brief Half-Edge 기본 요소 식별자
 */
using VertexIndex   = int32_t;
using HalfedgeIndex = int32_t;
using EdgeIndex     = int32_t;
using FaceIndex     = int32_t;

constexpr int32_t INVALID_INDEX = -1;

/**
 * @brief O(1) 위상 질의를 위한 Half-Edge 내부 원시 구조체
 */
struct HalfEdgeRecord {
    HalfedgeIndex twin = INVALID_INDEX;   ///< 반대 방향 Half-Edge
    HalfedgeIndex next = INVALID_INDEX;   ///< 같은 면의 다음 Half-Edge
    HalfedgeIndex prev = INVALID_INDEX;   ///< 같은 면의 이전 Half-Edge
    VertexIndex   vertex = INVALID_INDEX; ///< 시작 정점
    EdgeIndex     edge = INVALID_INDEX;   ///< 소속된 간선
    FaceIndex     face = INVALID_INDEX;   ///< 소속된 면 (경계면일 경우 INVALID_INDEX)
};

/**
 * @brief Half-Edge 기반 토폴로지 관리 클래스
 * 
 * Geometry Central의 ManifoldSurfaceMesh 철학을 따르며,
 * O(1) 인접성 탐색 및 4대 원시 위상 조작(Edge Split, Collapse, Flip)을 제공합니다.
 */
class HalfEdgeMesh {
public:
    HalfEdgeMesh() = default;

    /**
     * @brief 정규 인덱스 버퍼(F)로부터 Half-Edge 위상 그래프 구축
     */
    void BuildFromFaces(const int32_t* faces, std::size_t num_faces, std::size_t num_vertices);

    // O(1) 위상 질의
    [[nodiscard]] HalfedgeIndex Twin(HalfedgeIndex he) const noexcept { return halfedges_[he].twin; }
    [[nodiscard]] HalfedgeIndex Next(HalfedgeIndex he) const noexcept { return halfedges_[he].next; }
    [[nodiscard]] HalfedgeIndex Prev(HalfedgeIndex he) const noexcept { return halfedges_[he].prev; }
    [[nodiscard]] VertexIndex Vertex(HalfedgeIndex he) const noexcept { return halfedges_[he].vertex; }
    [[nodiscard]] FaceIndex Face(HalfedgeIndex he) const noexcept { return halfedges_[he].face; }
    [[nodiscard]] EdgeIndex Edge(HalfedgeIndex he) const noexcept { return halfedges_[he].edge; }

    [[nodiscard]] HalfedgeIndex VertexHalfedge(VertexIndex v) const noexcept { return vertex_halfedges_[v]; }
    [[nodiscard]] HalfedgeIndex FaceHalfedge(FaceIndex f) const noexcept { return face_halfedges_[f]; }

    // 1-Ring 정점 순회 (O(deg) = 평균 6단계)
    [[nodiscard]] std::vector<VertexIndex> Get1RingNeighbors(VertexIndex v) const;

    // 위상 원시 조작
    bool FlipEdge(EdgeIndex e);
    VertexIndex SplitEdge(EdgeIndex e, double split_ratio = 0.5);
    bool CollapseEdge(EdgeIndex e);

    // 정규 버퍼로 환원 시 압축
    void Compress(IndexBuffer& out_faces, std::size_t& out_num_faces);

    [[nodiscard]] std::size_t NumVertices() const noexcept { return vertex_halfedges_.size(); }
    [[nodiscard]] std::size_t NumFaces() const noexcept { return num_valid_faces_; }
    [[nodiscard]] std::size_t NumHalfedges() const noexcept { return halfedges_.size(); }

private:
    std::vector<HalfEdgeRecord> halfedges_;
    std::vector<HalfedgeIndex> vertex_halfedges_;
    std::vector<HalfedgeIndex> face_halfedges_;
    std::vector<HalfedgeIndex> edge_halfedges_;
    std::size_t num_valid_faces_ = 0;
};

/**
 * @brief Geometry Central 어댑터
 * 
 * 정규 버퍼와 HalfEdgeMesh 사이의 지연 동기화(Lazy Sync)를 관장합니다.
 */
class GeometryCentralAdapter {
public:
    GeometryCentralAdapter() = default;

    /**
     * @brief 정규 버퍼로부터 Half-Edge 위상 객체 생성 또는 동기화
     */
    std::shared_ptr<HalfEdgeMesh> SyncFromCanonical(
        const IndexBuffer& index_buffer,
        std::size_t num_faces,
        std::size_t num_vertices
    );

    /**
     * @brief 위상 변경 완료 후 정규 버퍼로 환원 동기화 (compress)
     */
    void SyncToCanonical(
        HalfEdgeMesh& he_mesh,
        IndexBuffer& out_index_buffer,
        std::size_t& out_num_faces
    );
};

} // namespace mesh_engine
