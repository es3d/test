#pragma once

#include "BufferPool.hpp"
#include "DirtyState.hpp"
#include "VtkAdapter.hpp"
#include "GeometryCentralAdapter.hpp"
#include "IglAdapter.hpp"

#include <memory>
#include <shared_mutex>
#include <atomic>
#include <string>
#include <functional>

namespace mesh_engine {

/**
 * @brief UnifiedMesh: Dual-Representation Zero-Copy 하이브리드 메시 코어
 * 
 * [설계 철학 & 핵심 개념]
 * 1. Single Source of Truth:
 *    - 정규(Canonical) 기하 데이터(V, F, N, UV)는 64바이트 정렬된 연속 메모리(Row-Major)에만 보관됩니다.
 * 2. Dual-Representation (하이브리드 뷰):
 *    - 수치 연산 및 GPU 렌더링 시: Row-Major Matrix View (Eigen/libigl/VTK 직접 바인딩)
 *    - 국소 위상 수정 및 기하 쿼리 시: Half-Edge View (Geometry Central / HalfEdgeMesh)
 * 3. Zero-Copy 파이프라인:
 *    - VTK vtkPoints에 V.data() 포인터를 직접 전달하여 메모리 복사 0바이트 달성
 * 4. Dirty Flag 기반 지연 동기화(Lazy Evaluation):
 *    - 정점 위치만 변경 시: VTK Modified()만 호출 (0.05ms)
 *    - 위상 변경 시: 필요 시점에만 Half-Edge compress 및 CellArray 동기화
 */
class UnifiedMesh {
public:
    using Ptr = std::shared_ptr<UnifiedMesh>;
    using ConstPtr = std::shared_ptr<const UnifiedMesh>;

    UnifiedMesh();
    ~UnifiedMesh() = default;

    // 복사 방지 (고유 버퍼 소유권 보장) 및 이동 허용
    UnifiedMesh(const UnifiedMesh&) = delete;
    UnifiedMesh& operator=(const UnifiedMesh&) = delete;
    UnifiedMesh(UnifiedMesh&&) noexcept;
    UnifiedMesh& operator=(UnifiedMesh&&) noexcept;

    /**
     * @brief 기본 정규 기하 데이터 설정 (초기화 또는 로드)
     */
    void Initialize(
        const double* vertices, std::size_t num_vertices,
        const int32_t* faces, std::size_t num_faces
    );

    // ========================================================
    // 1. Zero-Copy 가시화 인터페이스 (VTK)
    // ========================================================
    
    /**
     * @brief Zero-Copy로 바인딩된 vtkPolyData 획득
     * 
     * 내부적으로 vtkDoubleArray::SetArray(V.data(), size, 1)로 연결되어 있으며,
     * 정점이 수정되어도 메모리 재할당 없이 항상 동일한 주소를 참조합니다.
     */
    VtkPolyDataPtr GetVtkPolyData();

    // ========================================================
    // 2. Half-Edge 위상 제어 인터페이스 (Geometry Central)
    // ========================================================
    
    /**
     * @brief O(1) 위상 쿼리 및 국소 변이를 위한 Half-Edge 뷰 획득 (Lazy Sync)
     */
    std::shared_ptr<HalfEdgeMesh> GetHalfEdgeMesh();

    // ========================================================
    // 3. 기하 변형 인터페이스 (Zero-Copy 60 FPS 경로)
    // ========================================================
    
    /**
     * @brief 단일 정점 위치 갱신 (위상 불변)
     */
    void SetVertexPosition(std::size_t v_idx, double x, double y, double z);

    /**
     * @brief 정점 변위(Displacement) 적용 (위상 불변, 스컬프팅/ARAP에 최적)
     */
    void DisplaceVertex(std::size_t v_idx, double dx, double dy, double dz);

    /**
     * @brief 외부 연산자(예: libigl ARAP)가 직접 V 버퍼를 수정할 때 사용하는 블록
     */
    void DirectGeometryMutation(const std::function<void(double* v_ptr, std::size_t num_v)>& func);

    // ========================================================
    // 4. 위상 변경 인터페이스 (Topology Mutation)
    // ========================================================
    
    bool FlipEdge(EdgeIndex e);
    VertexIndex SplitEdge(EdgeIndex e, double split_ratio = 0.5);
    bool CollapseEdge(EdgeIndex e);

    // ========================================================
    // 5. 동기화 및 상태 관리 (Dirty Flag State Machine)
    // ========================================================
    
    void MarkGeometryDirty() noexcept;
    void MarkTopologyDirty() noexcept;
    void Synchronize();

    [[nodiscard]] DirtyFlags GetDirtyState() const noexcept { return dirty_state_.load(); }
    [[nodiscard]] bool IsClean() const noexcept { return dirty_state_.load() == DirtyFlags::CLEAN; }

    // ========================================================
    // 6. 메모리 진단 및 메타데이터 질의
    // ========================================================
    
    [[nodiscard]] std::size_t NumVertices() const noexcept { return num_vertices_; }
    [[nodiscard]] std::size_t NumFaces() const noexcept { return num_faces_; }

    [[nodiscard]] const double* GetVertexBufferPtr() const noexcept { return vertex_buffer_.Data(); }
    [[nodiscard]] double* GetMutableVertexBufferPtr() noexcept { return vertex_buffer_.Data(); }
    [[nodiscard]] const int32_t* GetFaceBufferPtr() const noexcept { return face_buffer_.Data(); }

    /**
     * @brief 포인터 동일성을 확인하여 Zero-Copy 상태를 콘솔에 검증 출력
     */
    void PrintMemoryDiagnostic() const;

private:
    void EnsureTopologySynchronized();
    void EnsureVtkSynchronized();

    // 동시성 제어 (멀티스레드 리더/라이터 락)
    mutable std::shared_mutex rw_mutex_;

    // Canonical Data (Single Source of Truth)
    VertexBuffer vertex_buffer_;
    IndexBuffer  face_buffer_;
    std::size_t  num_vertices_ = 0;
    std::size_t  num_faces_ = 0;

    // State Tracker
    std::atomic<DirtyFlags> dirty_state_{DirtyFlags::ALL_DIRTY};

    // Cached Views & Adapters
    VtkAdapter vtk_adapter_;
    VtkPolyDataPtr cached_vtk_poly_data_;

    GeometryCentralAdapter gc_adapter_;
    std::shared_ptr<HalfEdgeMesh> cached_he_mesh_;
};

} // namespace mesh_engine
