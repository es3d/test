#pragma once

#include <cstdint>
#include <string_view>

namespace mesh_engine {

/**
 * @brief Headless IPC 통신을 위한 불변 32바이트 고정 헤더
 * 
 * 어떤 API 버전이 진화하더라도 이 헤더의 크기와 바이너리 레이아웃은 영구 고정됩니다.
 */
#pragma pack(push, 8)
struct alignas(8) IpcHeader {
    uint32_t magic;              ///< 0x4D455348 ('MESH') 매직 넘버
    uint16_t protocol_version;   ///< 통신 프로토콜 버전 (e.g. 0x0100 for 1.0)
    uint16_t api_version;        ///< 요청하는 API 버전 (1, 2, 3...)
    uint32_t command_id;         ///< 명령 ID (101: Clean, 102: Remesh, 103: Boolean...)
    uint32_t flags;              ///< 제어 플래그 (비동기, 압축, 디버그 등)
    uint64_t payload_bytes;      ///< 뒤따르는 파라미터 직렬화 페이로드 크기
    uint64_t shared_mem_handle;  ///< Zero-Copy 대용량 지오메트리 공유 메모리 핸들
};
#pragma pack(pop)

static_assert(sizeof(IpcHeader) == 32, "IpcHeader must be exactly 32 bytes for binary stability!");

constexpr uint32_t MESH_IPC_MAGIC = 0x4D455348; // 'MESH'

enum CommandIds : uint32_t {
    CMD_HELLO_HANDSHAKE = 1,
    CMD_CLEAN_MESH      = 101,
    CMD_REMESH          = 102,
    CMD_EDIT_DEFORM     = 103,
    CMD_OFFSET          = 104,
    CMD_CUT             = 105,
    CMD_BOOLEAN         = 106,
};

enum ErrorCodes : int32_t {
    ERR_SUCCESS               = 0,
    ERR_INVALID_MAGIC         = -1,
    ERR_UNSUPPORTED_VERSION   = -2,
    ERR_UNKNOWN_COMMAND       = -3,
    ERR_PAYLOAD_CORRUPTED     = -4,
    ERR_GEOMETRY_INVALID      = -5
};

} // namespace mesh_engine
