#pragma once

#include <cstdint>
#include <string>
#include <string_view>
#include <atomic>

namespace mesh_engine {

/**
 * @brief UnifiedMesh의 동기화 상태 플래그
 * 
 * 비트 필드로 조합 가능하며, 연산 유형에 따른 최소 비용 동기화를 보장합니다.
 */
enum class DirtyFlags : uint32_t {
    CLEAN           = 0x00, ///< 모든 뷰(Matrix, HE, VTK)가 완전히 동기화됨
    GEOMETRY_DIRTY  = 0x01, ///< 정점 위치(V, N, UV)만 변경됨 (위상/삼각형 연결성은 불변)
    TOPOLOGY_DIRTY  = 0x02, ///< 삼각형 면(F) 또는 간선(E) 구조가 변경됨 (정점 수 변경 포함)
    VTK_DIRTY       = 0x04, ///< VTK 가시화 객체(vtkPolyData) 갱신 필요
    HE_DIRTY        = 0x08, ///< Half-Edge 위상 객체(ManifoldSurfaceMesh) 재구축 필요
    ALL_DIRTY       = 0xFF  ///< 기하, 위상, 모든 캐시 뷰 완전 재생성 필요
};

inline DirtyFlags operator|(DirtyFlags a, DirtyFlags b) {
    return static_cast<DirtyFlags>(static_cast<uint32_t>(a) | static_cast<uint32_t>(b));
}

inline DirtyFlags operator&(DirtyFlags a, DirtyFlags b) {
    return static_cast<DirtyFlags>(static_cast<uint32_t>(a) & static_cast<uint32_t>(b));
}

inline DirtyFlags operator~(DirtyFlags a) {
    return static_cast<DirtyFlags>(~static_cast<uint32_t>(a));
}

inline DirtyFlags& operator|=(DirtyFlags& a, DirtyFlags b) {
    a = a | b;
    return a;
}

inline bool HasFlag(DirtyFlags state, DirtyFlags flag) {
    return (static_cast<uint32_t>(state) & static_cast<uint32_t>(flag)) != 0;
}

inline std::string_view ToString(DirtyFlags state) {
    if (state == DirtyFlags::CLEAN) return "CLEAN";
    if (HasFlag(state, DirtyFlags::ALL_DIRTY)) return "ALL_DIRTY";
    if (HasFlag(state, DirtyFlags::TOPOLOGY_DIRTY)) return "TOPOLOGY_DIRTY";
    if (HasFlag(state, DirtyFlags::GEOMETRY_DIRTY)) return "GEOMETRY_DIRTY";
    return "UNKNOWN_DIRTY";
}

} // namespace mesh_engine
