#ifndef MESH_API_C_H
#define MESH_API_C_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32)
    #if defined(MESH_ENGINE_EXPORTS)
        #define MESH_C_API __declspec(dllexport)
    #else
        #define MESH_C_API __declspec(dllimport)
    #endif
#else
    #define MESH_C_API __attribute__((visibility("default")))
#endif

typedef void* MeshEngineContextHandle;
typedef void* MeshHandle;

/* ========================================================================= */
/* Version 1 Specification (Legacy Compatible)                              */
/* ========================================================================= */

typedef struct RemeshParams_v1 {
    uint32_t struct_size;          /* sizeof(RemeshParams_v1) */
    double target_edge_length;     /* 목표 간선 길이 */
    int32_t iterations;            /* 반복 횟수 */
} RemeshParams_v1;

MESH_C_API int32_t MeshEngine_Remesh_v1(
    MeshHandle mesh,
    const RemeshParams_v1* params
);

/* ========================================================================= */
/* Version 2 Specification (Modern Standard)                                 */
/* ========================================================================= */

typedef struct RemeshParams_v2 {
    uint32_t struct_size;          /* sizeof(RemeshParams_v2) */
    double target_edge_length;     /* 목표 간선 길이 */
    int32_t iterations;            /* 반복 횟수 */
    /* v2 신규 확장 필드 (끝에 추가) */
    double sharp_crease_angle;     /* 특징 모서리 보존 각도 (deg) */
    int32_t preserve_boundary;     /* 1: 경계 보존, 0: 경계 허용 */
    uint32_t feature_flags;        /* 미래 대비 예약 플래그 */
    char reserved[32];             /* 미래 확장을 위한 32바이트 패딩 (크기 고정) */
} RemeshParams_v2;

MESH_C_API int32_t MeshEngine_Remesh_v2(
    MeshHandle mesh,
    const RemeshParams_v2* params
);

/* ========================================================================= */
/* Engine Lifecycle & Version Query                                         */
/* ========================================================================= */

MESH_C_API uint32_t MeshEngine_GetSupportedApiVersionMax(void);
MESH_C_API const char* MeshEngine_GetVersionString(void);

#ifdef __cplusplus
}
#endif

#endif /* MESH_API_C_H */
