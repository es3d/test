#pragma once

#include <cstdlib>
#include <memory>
#include <vector>
#include <cassert>
#include <new>
#include <cstdint>
#include <cstddef>

namespace mesh_engine {

/**
 * @brief 64바이트 캐시라인 정렬 메모리 할당자 (AVX-512 / AVX2 SIMD 최적화)
 */
template <typename T, std::size_t Alignment = 64>
class AlignedAllocator {
public:
    using value_type      = T;
    using pointer         = T*;
    using const_pointer   = const T*;
    using size_type       = std::size_t;
    using difference_type = std::ptrdiff_t;

    AlignedAllocator() noexcept = default;

    template <typename U>
    AlignedAllocator(const AlignedAllocator<U, Alignment>&) noexcept {}

    template <typename U>
    struct rebind {
        using other = AlignedAllocator<U, Alignment>;
    };

    T* allocate(std::size_t n) {
        if (n == 0) return nullptr;
        std::size_t bytes = n * sizeof(T);
#if defined(_MSC_VER) || defined(__MINGW32__)
        void* ptr = _aligned_malloc(bytes, Alignment);
#else
        void* ptr = nullptr;
        if (posix_memalign(&ptr, Alignment, bytes) != 0) {
            ptr = nullptr;
        }
#endif
        if (!ptr) throw std::bad_alloc();
        return static_cast<T*>(ptr);
    }

    void deallocate(T* p, std::size_t) noexcept {
        if (!p) return;
#if defined(_MSC_VER) || defined(__MINGW32__)
        _aligned_free(p);
#else
        free(p);
#endif
    }

    bool operator==(const AlignedAllocator&) const noexcept { return true; }
    bool operator!=(const AlignedAllocator&) const noexcept { return false; }
};

/**
 * @brief Zero-Copy 공유 버퍼 클래스
 * 
 * 정규(Canonical) 기하 데이터(정점 V, 법선 N, UV)와 위상 인덱스(면 F)를
 * 1차원 연속 메모리(Row-Major) 형태로 유지하며, VTK 및 Eigen/GeometryCentral이
 * 동일한 메모리 주소를 복사 없이 직접 참조하도록 보장합니다.
 */
template <typename T>
class SharedBuffer {
public:
    using AlignedVector = std::vector<T, AlignedAllocator<T, 64>>;

    SharedBuffer() = default;

    explicit SharedBuffer(std::size_t total_elements) {
        Resize(total_elements);
    }

    void Resize(std::size_t total_elements) {
        data_.resize(total_elements);
    }

    void Reserve(std::size_t total_elements) {
        data_.reserve(total_elements);
    }

    [[nodiscard]] T* Data() noexcept { return data_.data(); }
    [[nodiscard]] const T* Data() const noexcept { return data_.data(); }

    [[nodiscard]] std::size_t Size() const noexcept { return data_.size(); }
    [[nodiscard]] std::size_t Capacity() const noexcept { return data_.capacity(); }
    [[nodiscard]] bool Empty() const noexcept { return data_.empty(); }

    void Clear() noexcept { data_.clear(); }

    // 64바이트 캐시라인 정렬 검증
    [[nodiscard]] bool IsAligned64() const noexcept {
        return (reinterpret_cast<std::uintptr_t>(data_.data()) % 64) == 0;
    }

    AlignedVector& GetVector() noexcept { return data_; }
    const AlignedVector& GetVector() const noexcept { return data_; }

private:
    AlignedVector data_;
};

using VertexBuffer = SharedBuffer<double>;
using IndexBuffer  = SharedBuffer<int32_t>;

} // namespace mesh_engine
