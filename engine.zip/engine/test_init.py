import os
import sys
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

# Color Palette Definitions
C_BG = RGBColor(10, 15, 29)          # #0A0F1D Deep Obsidian Navy
C_CARD_BG = RGBColor(19, 28, 49)     # #131C31 Dark Slate Panel
C_CARD_ALT = RGBColor(26, 38, 66)    # #1A2642 Slightly lighter slate
C_BORDER = RGBColor(46, 62, 95)      # #2E3E5F Card border
C_BORDER_BRIGHT = RGBColor(0, 210, 255) # Cyan highlight border

C_TEXT_WHITE = RGBColor(248, 250, 252) # #F8FAFC
C_TEXT_MUTED = RGBColor(148, 163, 184) # #94A3B8
C_TEXT_DIM = RGBColor(100, 116, 139)   # #64748B

C_CYAN = RGBColor(0, 229, 255)       # #00E5FF Primary Accent
C_BLUE = RGBColor(59, 130, 246)      # #3B82F6 Royal Blue
C_EMERALD = RGBColor(16, 185, 129)   # #10B981 Green / Success
C_AMBER = RGBColor(245, 158, 11)     # #F59E0B Amber / Warning
C_PURPLE = RGBColor(168, 85, 247)    # #A855F7 Purple / Core
C_ROSE = RGBColor(244, 63, 94)       # #F43F5E Rose / Accent

FONT_TITLE = "Malgun Gothic"
FONT_BODY = "Malgun Gothic"
FONT_CODE = "Consolas"

def create_deck():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank_layout = prs.slide_layouts[6]
    return prs, blank_layout

print("Script framework ready.")
