import os
import sys
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

# -------------------------------------------------------------
# Color Palette (Dark Obsidian Canvas with High-Contrast Tech Accents)
# -------------------------------------------------------------
C_BG            = RGBColor(8, 12, 21)        # #080C15 Deep Obsidian
C_CARD_BG       = RGBColor(16, 23, 40)       # #101728 Slate Card
C_CARD_ALT      = RGBColor(23, 33, 56)       # #172138 Card Header/Accent
C_BORDER        = RGBColor(38, 54, 82)       # #263652 Subtle Border
C_BORDER_ACCENT = RGBColor(0, 229, 255)      # #00E5FF Cyan Stroke

C_WHITE         = RGBColor(248, 250, 252)    # #F8FAFC Primary Title
C_TEXT_LIGHT    = RGBColor(226, 232, 240)    # #E2E8F0 Body Text
C_TEXT_MUTED    = RGBColor(148, 163, 184)    # #94A3B8 Secondary Text
C_TEXT_DIM      = RGBColor(100, 116, 139)    # #64748B Inactive Text

C_CYAN          = RGBColor(0, 229, 255)      # #00E5FF Primary Cyan
C_BLUE          = RGBColor(59, 130, 246)     # #3B82F6 Royal Blue
C_EMERALD       = RGBColor(16, 185, 129)     # #10B981 Emerald Green
C_AMBER         = RGBColor(245, 158, 11)     # #F59E0B Warm Amber
C_PURPLE        = RGBColor(168, 85, 247)     # #A855F7 Purple Accent
C_ROSE          = RGBColor(244, 63, 94)      # #F43F5E Warning / Deprecation

FONT_HEADING = "Malgun Gothic"
FONT_BODY    = "Malgun Gothic"
FONT_CODE    = "Consolas"

TOTAL_SLIDES = 17

def create_deck():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank_layout = prs.slide_layouts[6]
    return prs, blank_layout

def set_shape_flat(shape, fill_color, border_color=None, border_width=1):
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    if border_color:
        shape.line.color.rgb = border_color
        shape.line.width = Pt(border_width)
    else:
        shape.line.fill.background()

def create_base_slide(prs, blank_layout, cat_tag, title, subtitle, slide_num):
    slide = prs.slides.add_slide(blank_layout)
    
    # Background
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Inches(13.333), Inches(7.5))
    set_shape_flat(bg, C_BG)
    
    # Top accent bar
    accent_bar = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(0.4), Inches(2.5), Inches(0.04))
    set_shape_flat(accent_bar, C_CYAN)

    # Title & Subtitle Box
    title_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.48), Inches(11.733), Inches(1.05))
    tf = title_box.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_top = tf.margin_right = tf.margin_bottom = 0
    
    # Category Tag
    p_tag = tf.paragraphs[0]
    p_tag.text = cat_tag.upper()
    p_tag.font.name = FONT_HEADING
    p_tag.font.size = Pt(10)
    p_tag.font.bold = True
    p_tag.font.color.rgb = C_CYAN
    p_tag.space_after = Pt(2)
    
    # Main Title
    p_title = tf.add_paragraph()
    p_title.text = title
    p_title.font.name = FONT_HEADING
    p_title.font.size = Pt(21)
    p_title.font.bold = True
    p_title.font.color.rgb = C_WHITE
    p_title.space_after = Pt(2)
    
    # Subtitle
    if subtitle:
        p_sub = tf.add_paragraph()
        p_sub.text = subtitle
        p_sub.font.name = FONT_BODY
        p_sub.font.size = Pt(11)
        p_sub.font.color.rgb = C_TEXT_MUTED
        
    # Footer Line
    f_line = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(7.05), Inches(11.733), Inches(0.02))
    set_shape_flat(f_line, C_BORDER)
    
    # Footer Left
    f_box_l = slide.shapes.add_textbox(Inches(0.8), Inches(7.1), Inches(8.0), Inches(0.3))
    tf_l = f_box_l.text_frame
    tf_l.margin_left = tf_l.margin_top = tf_l.margin_right = tf_l.margin_bottom = 0
    p_fl = tf_l.paragraphs[0]
    p_fl.text = "Headless Mesh Engine Architecture  |  API Versioning, Compatibility & Governance Strategy"
    p_fl.font.name = FONT_BODY
    p_fl.font.size = Pt(9)
    p_fl.font.color.rgb = C_TEXT_DIM
    
    # Footer Right
    f_box_r = slide.shapes.add_textbox(Inches(10.533), Inches(7.1), Inches(2.0), Inches(0.3))
    tf_r = f_box_r.text_frame
    tf_r.margin_left = tf_r.margin_top = tf_r.margin_right = tf_r.margin_bottom = 0
    p_fr = tf_r.paragraphs[0]
    p_fr.alignment = PP_ALIGN.RIGHT
    p_fr.text = f"{slide_num:02d} / {TOTAL_SLIDES:02d}"
    p_fr.font.name = FONT_HEADING
    p_fr.font.size = Pt(9)
    p_fr.font.bold = True
    p_fr.font.color.rgb = C_CYAN
    
    return slide

def add_card(slide, left, top, width, height, bg_color=C_CARD_BG, border_color=C_BORDER, border_width=1):
    card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(left), Inches(top), Inches(width), Inches(height))
    set_shape_flat(card, bg_color, border_color, border_width)
    return card

def add_feature_card(slide, left, top, width, height, tag, title, bullets, accent_color=C_CYAN):
    card = add_card(slide, left, top, width, height, bg_color=C_CARD_BG, border_color=C_BORDER)
    
    tb = slide.shapes.add_textbox(Inches(left + 0.25), Inches(top + 0.22), Inches(width - 0.5), Inches(height - 0.4))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_top = tf.margin_right = tf.margin_bottom = 0
    
    p_tag = tf.paragraphs[0]
    p_tag.text = f"[{tag.upper()}]"
    p_tag.font.name = FONT_HEADING
    p_tag.font.size = Pt(9.5)
    p_tag.font.bold = True
    p_tag.font.color.rgb = accent_color
    p_tag.space_after = Pt(2)
    
    p_title = tf.add_paragraph()
    p_title.text = title
    p_title.font.name = FONT_HEADING
    p_title.font.size = Pt(13.5)
    p_title.font.bold = True
    p_title.font.color.rgb = C_WHITE
    p_title.space_after = Pt(8)
    
    for b in bullets:
        p_b = tf.add_paragraph()
        p_b.text = f"•  {b}"
        p_b.font.name = FONT_BODY
        p_b.font.size = Pt(10)
        p_b.font.color.rgb = C_TEXT_LIGHT
        p_b.space_after = Pt(4)
        
    return card

def add_kpi_card(slide, left, top, width, height, value, label, subtext="", accent_color=C_CYAN):
    card = add_card(slide, left, top, width, height, bg_color=C_CARD_BG, border_color=C_BORDER)
    
    bar = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(left + 0.15), Inches(top + 0.15), Inches(0.6), Inches(0.05))
    set_shape_flat(bar, accent_color)
    
    tb = slide.shapes.add_textbox(Inches(left + 0.15), Inches(top + 0.28), Inches(width - 0.3), Inches(height - 0.35))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_top = tf.margin_right = tf.margin_bottom = 0
    
    p_val = tf.paragraphs[0]
    p_val.text = value
    p_val.font.name = FONT_HEADING
    p_val.font.size = Pt(26)
    p_val.font.bold = True
    p_val.font.color.rgb = accent_color
    p_val.space_after = Pt(2)
    
    p_lbl = tf.add_paragraph()
    p_lbl.text = label
    p_lbl.font.name = FONT_HEADING
    p_lbl.font.size = Pt(11)
    p_lbl.font.bold = True
    p_lbl.font.color.rgb = C_WHITE
    p_lbl.space_after = Pt(2)
    
    if subtext:
        p_sub = tf.add_paragraph()
        p_sub.text = subtext
        p_sub.font.name = FONT_BODY
        p_sub.font.size = Pt(9.5)
        p_sub.font.color.rgb = C_TEXT_MUTED
    return card

def add_table_custom(slide, left, top, width, height, headers, rows, col_widths=None):
    num_rows = len(rows) + 1
    num_cols = len(headers)
    table_shape = slide.shapes.add_table(num_rows, num_cols, Inches(left), Inches(top), Inches(width), Inches(height))
    table = table_shape.table
    
    if col_widths and len(col_widths) == num_cols:
        for idx, w in enumerate(col_widths):
            table.columns[idx].width = Inches(w)
            
    for c_idx, h_text in enumerate(headers):
        cell = table.cell(0, c_idx)
        cell.fill.solid()
        cell.fill.fore_color.rgb = C_CARD_ALT
        cell.vertical_anchor = MSO_ANCHOR.MIDDLE
        tf = cell.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_right = Inches(0.12)
        p = tf.paragraphs[0]
        p.text = h_text
        p.font.name = FONT_HEADING
        p.font.size = Pt(10.5)
        p.font.bold = True
        p.font.color.rgb = C_CYAN
        
    for r_idx, row_data in enumerate(rows):
        bg = C_CARD_BG if r_idx % 2 == 0 else RGBColor(12, 18, 32)
        for c_idx, val in enumerate(row_data):
            cell = table.cell(r_idx + 1, c_idx)
            cell.fill.solid()
            cell.fill.fore_color.rgb = bg
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            tf = cell.text_frame
            tf.word_wrap = True
            tf.margin_left = tf.margin_right = Inches(0.12)
            p = tf.paragraphs[0]
            p.text = str(val)
            p.font.name = FONT_BODY
            p.font.size = Pt(9.5)
            p.font.color.rgb = C_WHITE if c_idx == 0 else C_TEXT_LIGHT
            if c_idx == 0:
                p.font.bold = True
                
    return table_shape

# -------------------------------------------------------------
# BUILD 17 HIGH-IMPACT SLIDES FOR HEADLESS API VERSIONING
# -------------------------------------------------------------

def build_presentation():
    prs, blank_layout = create_deck()
    print("Building 17 Headless API Versioning slides...")

    # SLIDE 1: Cover
    slide1 = prs.slides.add_slide(blank_layout)
    bg1 = slide1.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Inches(13.333), Inches(7.5))
    set_shape_flat(bg1, C_BG)
    
    glow1 = slide1.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(0.8), Inches(11.733), Inches(5.9))
    set_shape_flat(glow1, C_CARD_BG, C_BORDER, 1)
    
    top_line = slide1.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(0.8), Inches(11.733), Inches(0.08))
    set_shape_flat(top_line, C_CYAN)
    
    tb1 = slide1.shapes.add_textbox(Inches(1.5), Inches(1.4), Inches(10.333), Inches(4.5))
    tf1 = tb1.text_frame
    tf1.word_wrap = True
    
    p = tf1.paragraphs[0]
    p.text = "HEADLESS ENGINE GOVERNANCE & EVOLUTION STRATEGY"
    p.font.name = FONT_HEADING
    p.font.size = Pt(12)
    p.font.bold = True
    p.font.color.rgb = C_CYAN
    p.space_after = Pt(14)
    
    p = tf1.add_paragraph()
    p.text = "Headless 메시 프로세싱 엔진"
    p.font.name = FONT_HEADING
    p.font.size = Pt(36)
    p.font.bold = True
    p.font.color.rgb = C_WHITE
    
    p = tf1.add_paragraph()
    p.text = "버전별 API 관리 및 호환성 아키텍처 전략"
    p.font.name = FONT_HEADING
    p.font.size = Pt(30)
    p.font.bold = True
    p.font.color.rgb = C_CYAN
    p.space_after = Pt(16)
    
    p = tf1.add_paragraph()
    p.text = "GUI 의존성이 분리된 백엔드/IPC 환경에서 발생하는 API 잦은 변경을 해결하고,\n안정적인 다중 버전 공존, 무중단 하위 호환성, ABI 안정성 및 라이프사이클 관리를 구현하는 프레임워크 설계"
    p.font.name = FONT_BODY
    p.font.size = Pt(13)
    p.font.color.rgb = C_TEXT_LIGHT
    p.space_after = Pt(28)
    
    p = tf1.add_paragraph()
    p.text = "⚡ Headless IPC Architecture   |   🔷 SemVer 2.0 Governance   |   🛡 Stable C-ABI Barrier   |   🔄 Multi-Version Router"
    p.font.name = FONT_HEADING
    p.font.size = Pt(11)
    p.font.bold = True
    p.font.color.rgb = C_EMERALD

    # SLIDE 2: Executive Summary
    slide2 = create_base_slide(prs, blank_layout, "Executive Summary",
                               "Headless 엔진 도입 배경과 API 버전 관리의 필연성",
                               "렌더링/UI 분리 구조에서 API 파편화와 클라이언트 충돌을 원천 방지하는 3대 핵심 기둥", 2)
    
    add_feature_card(slide2, 0.8, 1.8, 3.75, 3.5, "Pillar 1: Headless Decoupling", "UI와 연산 엔진의 완전 분리", [
        "Headless 엔진: GUI 윈도우 루프 없이 백그라운드 프로세스/데몬으로 동작",
        "클라이언트(Tauri/Electron/Web/CLI)와 IPC/소켓을 통해 통신",
        "독립 배포 및 분산 스케일링이 가능해지지만, 클라이언트와 엔진의 릴리즈 주기가 어긋나는 문제 발생"
    ], C_CYAN)

    add_feature_card(slide2, 4.79, 1.8, 3.75, 3.5, "Pillar 2: Version Volatility", "잦은 알고리즘 스펙 변경", [
        "지오메트리 파라미터 추가 (예: 리메싱 허용 오차, 피처 보존 각도)",
        "신규 연산자 추가 및 반환 포맷 고도화 (진행률, 토폴로지 진단 리포트)",
        "버전 관리 체계가 없으면 구버전 클라이언트의 요청 시 즉시 크래시(Crash) 발생"
    ], C_AMBER)

    add_feature_card(slide2, 8.78, 1.8, 3.75, 3.5, "Pillar 3: Unified Governance", "버전 거버넌스 아키텍처", [
        "SemVer 2.0.0 규칙에 기반한 엄격한 스펙 진화",
        "C-ABI Stable Barrier & Schema Contract (FlatBuffers/Protobuf)",
        "다중 버전 공존 디스패처(Version Router) 및 점진적 Deprecation 파이프라인 구축"
    ], C_EMERALD)

    add_kpi_card(slide2, 0.8, 5.5, 3.75, 1.35, "Zero Crash", "하위 호환성 100% 보장", "구버전 클라이언트 변경 없이 동작", C_CYAN)
    add_kpi_card(slide2, 4.79, 5.5, 3.75, 1.35, "Multi-Version", "v1, v2, v3 동시 공존", "버전 라우터 기반 지연 디스패치", C_EMERALD)
    add_kpi_card(slide2, 8.78, 5.5, 3.75, 1.35, "Zero-Copy IPC", "대용량 메시 호환성", "공유 메모리 핸드셰이크 프로토콜", C_PURPLE)

    # SLIDE 3: The 4 Pitfalls of API Evolution
    slide3 = create_base_slide(prs, blank_layout, "Problem Analysis",
                               "버전 관리 부재 시 발생하는 4대 치명적 병목 (Pitfalls)",
                               "단순 함수 변경이 전체 시스템을 붕괴시키는 원인과 C++ 엔지니어링의 함정", 3)
    
    add_feature_card(slide3, 0.8, 1.8, 2.75, 4.95, "Pitfall 1", "C++ ABI Hell & Name Mangling", [
        "컴파일러 버전/플래그 변경 시 vtable 오프셋 변조",
        "std::string, std::vector 구조체 메모리 레이아웃 불일치",
        "DLL/SO 동적 링크 시 런타임 Crash 발생",
        "클라이언트와 엔진의 컴파일러 툴체인 종속성 고착"
    ], C_ROSE)

    add_feature_card(slide3, 3.79, 1.8, 2.75, 4.95, "Pitfall 2", "Struct Memory Drift", [
        "파라미터 구조체에 필드 1개 추가 시 크기(sizeof) 변경",
        "구버전 클라이언트가 신버전 엔진에 IPC 패킷 전송 시 오프셋 어긋남(Memory Corruption)",
        "기본값 미지정으로 인한 댕글링 포인터 및 정의되지 않은 동작"
    ], C_AMBER)

    add_feature_card(slide3, 6.78, 1.8, 2.75, 4.95, "Pitfall 3", "Zero-Copy Protocol Breakdown", [
        "정규 버퍼 레이아웃(Row-Major 등) 변경 시 역호환성 파괴",
        "버전별 공유 메모리 헤더가 없으면 다른 형식으로 해석하여 렌더링 왜곡",
        "고속 통신 이점이 데이터 변환 오버헤드로 변질"
    ], C_PURPLE)

    add_feature_card(slide3, 9.77, 1.8, 2.75, 4.95, "Pitfall 4", "Client-Engine Lockstep", [
        "엔진 업데이트 시 모든 클라이언트 앱(Tauri 등) 동시 강제 재배포 필요",
        "레거시 파일/프로젝트 로드 불가",
        "개발 속도 저하 및 유지보수 비용 기하급수적 증가"
    ], C_CYAN)

    # SLIDE 4: Semantic Versioning Governance
    slide4 = create_base_slide(prs, blank_layout, "Versioning Principles",
                               "SemVer 2.0 기반 메시 엔진 버전 명명 및 호환성 계약",
                               "MAJOR.MINOR.PATCH 릴리즈 규칙과 클라이언트-엔진 간 법적 계약(Contract)", 4)
    
    headers4 = ["버전 단위", "변경 성격", "호환성 보장 범위", "메시 엔진 적용 구체 사례", "클라이언트 영향도"]
    rows4 = [
        ["MAJOR (X.0.0)", "하위 호환성 파괴 (Breaking Changes)", "이전 메이저 버전과 비호환 (새 엔드포인트 분리)", "• 정규 버퍼 포맷 변경\n• 필수 인자 제거\n• HalfEdge 구조체 전면 개편", "어댑터 코드 수정 또는 버전 마이그레이션 필수"],
        ["MINOR (x.Y.0)", "하위 호환 신기능 추가 (Backwards-Compatible)", "동일 메이저 내 완벽한 하위 호환 보장", "• 신규 6대 API 추가 (예: V2.1에 Offset 추가)\n• 기존 옵션 구조체에 선택적 필드 추가\n• 진행률 콜백 스트림 확장", "클라이언트 무수정 동작 (신규 기능은 선택적 호출)"],
        ["PATCH (x.y.Z)", "하위 호환 버그 수정 (Bug Fixes)", "API 시그니처 100% 동일 유지", "• CGAL 불리언 교차 수치 안정성 패치\n• 메모리 누수 수정\n• SIMD 정렬 연산 최적화", "투명한 드롭인(Drop-in) 교체 가능"]
    ]
    add_table_custom(slide4, 0.8, 1.8, 11.733, 3.4, headers4, rows4, [1.8, 2.8, 2.8, 2.5, 1.833])

    add_feature_card(slide4, 0.8, 5.4, 11.733, 1.45, "Compatibility Contract Guarantee", "엔진 개발팀의 3대 불변 약속 (Contract Rules)", [
        "1. 기존 필드 이름이나 의미를 변경하지 않는다 (수정이 필요하면 새 필드 추가 후 기존 필드 Deprecated 처리)",
        "2. 신규 필드는 반드시 기본값(Default)을 명시하여 구버전 클라이언트의 누락 요청을 안전하게 처리한다",
        "3. 동일 MAJOR 버전 내에서는 클라이언트가 재컴파일 없이 신버전 엔진 바이너리로 즉시 교체 가능해야 한다"
    ], C_EMERALD)

    # SLIDE 5: 3-Tier Headless Engine Architecture
    slide5 = create_base_slide(prs, blank_layout, "System Architecture",
                               "Headless 엔진 3-Tier 레이어링 구조",
                               "물리적 연산 코어와 버전 관리, 통신 프로토콜을 철저하게 분리한 계층 아키텍처", 5)
    
    add_feature_card(slide5, 0.8, 1.8, 3.75, 4.95, "Layer 1: Transport & Dispatch", "[외부 통신] Headless Gateway", [
        "다양한 통신 채널 수용:",
        "  • IPC: Shared Memory + Named Pipes (초고속 로컬)",
        "  • RPC: gRPC / Protocol Buffers (원격/마이크로서비스)",
        "  • FFI: C-ABI Dynamic Library (.dll / .so)",
        "Version Handshake & Protocol Sniffing:",
        "  • 클라이언트 요청 헤더에서 version 번호 파싱",
        "  • 지원 가능한 최적의 API 어댑터로 즉시 라우팅"
    ], C_CYAN)

    add_feature_card(slide5, 4.79, 1.8, 3.75, 4.95, "Layer 2: Version Adapter Suite", "[버전 격리] API Adapter Layer", [
        "다중 버전 어댑터 동시 상주:",
        "  • MeshApiAdapter_V1 (레거시 지원)",
        "  • MeshApiAdapter_V2 (현재 표준)",
        "  • MeshApiAdapter_V3 (최신/실험 기능)",
        "Schema & Parameter Normalization:",
        "  • V1 파라미터를 V2/V3 정규 구조체로 변환",
        "  • 기본값 보정 및 누락 옵션 자동 채움",
        "  • 레거시 호출에 대한 Deprecation 텔레메트리 기록"
    ], C_BLUE)

    add_feature_card(slide5, 8.78, 1.8, 3.75, 4.95, "Layer 3: Canonical Core Engine", "[불변 코어] UnifiedMesh Engine", [
        "버전과 무관한 순수 C++20 고성능 기하 코어:",
        "  • UnifiedMesh (Row-Major 64바이트 버퍼)",
        "  • 6대 기하 알고리즘 라이브러리 (Cleaning, Remeshing...)",
        "  • VTK Headless Offscreen 파이프라인 (EGL/OSMesa)",
        "핵심 이점:",
        "  • 알고리즘 코어는 버전 변환 로직을 일체 모름!",
        "  • 유지보수 복잡도가 코어 엔진으로 전파되지 않음"
    ], C_EMERALD)

    # SLIDE 6: Schema Evolution (Protobuf / FlatBuffers vs C-ABI)
    slide6 = create_base_slide(prs, blank_layout, "Schema Serialization",
                               "스키마 진화 기술 비교: FlatBuffers / Protobuf vs C-Struct",
                               "Headless 메시 엔진에 가장 적합한 직렬화 및 스키마 진화 방식 분석", 6)
    
    headers6 = ["비교 항목", "C-Struct (Fixed Binary)", "Protocol Buffers (v3)", "FlatBuffers (Zero-Copy)"]
    rows6 = [
        ["스키마 진화 유연성", "매우 낮음 (패딩/필드 추가 시 크기 변경 위험)", "매우 높음 (Field ID 기반 완전 하위 호환)", "매우 높음 (vtable 기반 필드 오프셋 해석)"],
        ["직렬화/역직렬화 비용", "0 (메모리 캐스팅)", "중간 (파싱 및 객체 생성 오버헤드)", "0 (Zero-Copy 직렬화 없이 메모리 직접 읽기)"],
        ["대용량 지오메트리 전송", "적합 (포인터 직접 공유)", "부적합 (수백만 정점 복사 발생)", "매우 적합 (Raw 버퍼 직접 주입)"],
        ["언어 간 호환성 (FFI)", "C/C++, Rust 완벽, 타 언어 제한적", "모든 언어 (Rust, JS, Python) 지원", "모든 언어 (Rust, C++, WebAssembly) 지원"],
        ["권장 적용 영역", "초고속 로컬 C-ABI / 공유 메모리 헤더", "원격 네트워크 gRPC 제어 메시지", "로컬 IPC 대용량 메시 교환 표준"]
    ]
    add_table_custom(slide6, 0.8, 1.8, 11.733, 3.4, headers6, rows6, [2.2, 3.1, 3.2, 3.233])

    add_feature_card(slide6, 0.8, 5.4, 11.733, 1.45, "Hybrid Schema Strategy Recommendation", "하이브리드 전략 권장 (Hybrid Architecture)", [
        "1. 제어 신호 및 파라미터 (Control Plane): FlatBuffers 또는 버저닝된 C-Header 사용 (필드 ID 기반 안전 확장)",
        "2. 대용량 정점/면 데이터 (Data Plane): Shared Memory 버퍼 핸들(포인터+크기)만 전달하여 0-복사 유지"
    ], C_CYAN)

    # SLIDE 7: Stable C-ABI Barrier & COM-like Pattern
    slide7 = create_base_slide(prs, blank_layout, "ABI Stability",
                               "Stable C-ABI Barrier & 인터페이스 상속 패턴",
                               "C++ 컴파일러 차이와 맹글링을 극복하고 ABI를 영구적으로 안정화하는 설계 기법", 7)
    
    add_feature_card(slide7, 0.8, 1.8, 5.7, 4.95, "Pattern 1: Stable C-ABI Function Table", "순수 C 함수 테이블 바운더리 (C-ABI Barrier)", [
        "원칙: DLL/SO 경계에서는 절대 C++ 클래스나 STL 객체를 직접 노출하지 않음",
        "extern \"C\" 기반 함수 포인터 테이블 정의:",
        "  typedef struct MeshEngine_API_v1 {",
        "      uint32_t version; // 1",
        "      MeshHandle (*create_mesh)(const double* v, size_t nv, ...);",
        "      int (*remesh)(MeshHandle h, const RemeshParams_v1* p);",
        "      void (*destroy_mesh)(MeshHandle h);",
        "  } MeshEngine_API_v1;",
        "장점:",
        "  • Rust (Tauri), C#, Python, C++ 어느 언어에서든 100% 안전 호출",
        "  • 컴파일러 업그레이드 시에도 바이너리 호환성 영구 보존"
    ], C_CYAN)

    add_feature_card(slide7, 6.83, 1.8, 5.7, 4.95, "Pattern 2: COM-Style Interface Inheritance", "COM 스타일 버전별 인터페이스 상속", [
        "순수 가상 기본 클래스를 통한 버전 확장:",
        "  class IMeshEngine_v1 {",
        "  public:",
        "      virtual int Remesh(const RemeshParams_v1& p) = 0;",
        "  };",
        "  class IMeshEngine_v2 : public IMeshEngine_v1 {",
        "  public:",
        "      // v1 메서드는 그대로 상속받고, v2 신규 메서드 추가",
        "      virtual int RemeshV2(const RemeshParams_v2& p) = 0;",
        "      virtual int Boolean(const BooleanParams_v2& p) = 0;",
        "  };",
        "QueryInterface(UUID/Version):",
        "  • 클라이언트가 요청한 버전에 맞는 인터페이스 포인터 안전 반환"
    ], C_BLUE)

    # SLIDE 8: Headless IPC Protocol with Version Handshake
    slide8 = create_base_slide(prs, blank_layout, "IPC Protocol",
                               "Headless IPC 패킷 구조 및 버전 핸드셰이크 프로토콜",
                               "공유 메모리(Shared Memory)와 명명된 파이프(Named Pipe)를 통한 안전한 세션 수립", 8)
    
    add_feature_card(slide8, 0.8, 1.8, 5.7, 4.95, "IPC Packet Header Specification", "버전 헤더가 포함된 IPC 패킷 규격", [
        "모든 메시지의 선두에 배치되는 32바이트 고정 헤더:",
        "struct alignas(8) IpcMessageHeader {",
        "    uint32_t magic;          // 0x4D455348 ('MESH')",
        "    uint16_t protocol_ver;   // 프로토콜 메이저/마이너 (e.g. 0x0200)",
        "    uint16_t api_version;    // 요청 API 버전 (1, 2, 3...)",
        "    uint32_t command_id;     // 101: Clean, 102: Remesh...",
        "    uint64_t payload_size;   // 파라미터 페이로드 크기",
        "    uint64_t shared_mem_id;  // 공유 메모리 버퍼 식별자 (Zero-Copy)",
        "    uint32_t flags;          // 압축, 동기/비동기, 디버그 플래그",
        "    uint32_t reserved;       // 미래 확장을 위한 예약 필드",
        "};",
        "헤더 자체는 절대 크기가 변하지 않는 불변 규격으로 제정"
    ], C_CYAN)

    add_feature_card(slide8, 6.83, 1.8, 5.7, 4.95, "Version Negotiation Handshake", "초기 접속 시 버전 협상(Handshake) 절차", [
        "1. Client -> Engine: HELLO_REQ",
        "   - Client 지원 버전 목록 전달: [v1.0, v1.2, v2.0]",
        "2. Engine -> Client: HELLO_ACK",
        "   - Engine 지원 버전: [v1.0, v2.0, v2.1, v3.0-alpha]",
        "   - 최종 협상 버전: v2.0 결정",
        "3. 세션 고정:",
        "   - 해당 IPC 세션 동안은 v2.0 스키마로 모든 파라미터 패킷 직렬화",
        "4. 비호환 처리:",
        "   - 일치하는 MAJOR 버전이 없으면 에러 코드(VERSION_MISMATCH) 반환 및 클라이언트에 업그레이드 권고"
    ], C_EMERALD)

    # SLIDE 9: Multi-Version Coexistence & Dispatch Router
    slide9 = create_base_slide(prs, blank_layout, "Dispatch Router",
                               "다중 버전 공존 및 동적 디스패치 라우터",
                               "구버전 v1과 최신 v2/v3 요청을 단일 엔진 프로세스에서 동시에 분기 처리하는 아키텍처", 9)
    
    add_feature_card(slide9, 0.8, 1.8, 5.7, 4.95, "Version Router Architecture", "버전 라우터 (Version Router) 구조", [
        "동적 핸들러 매핑 테이블:",
        "  std::map<uint16_t, std::shared_ptr<IApiHandler>> handlers_;",
        "디스패치 흐름:",
        "  1. IpcMessage 수신",
        "  2. header.api_version 확인 (예: v1 vs v2)",
        "  3. handlers_[header.api_version]->Handle(message) 호출",
        "이점:",
        "  • v1 클라이언트와 v2 클라이언트가 동일한 엔진 백엔드에 동시 접속 가능",
        "  • 신규 버전 출시가 기존 운영 클라이언트에 0% 영향"
    ], C_CYAN)

    add_feature_card(slide9, 6.83, 1.8, 5.7, 4.95, "Adapter & Facade Normalization", "어댑터를 통한 코어 엔진 호출 단일화", [
        "레거시 v1 어댑터 내부 동작:",
        "  void ApiHandler_V1::HandleRemesh(Packet pkt) {",
        "      RemeshParams_v1 p1 = ParseV1(pkt);",
        "      // v1 파라미터를 최신 코어 UnifiedParams로 변환!",
        "      RemeshParams_Core core_p;",
        "      core_p.target_len = p1.target_edge_length;",
        "      core_p.iterations = p1.iterations;",
        "      core_p.feature_angle = 30.0; // V2 신규 필드는 기본값 주입!",
        "      core_engine_->Remesh(core_p);",
        "  }",
        "효과: 코어 알고리즘 코드는 항상 최신 1벌만 유지!"
    ], C_BLUE)

    # SLIDE 10: Backward & Forward Compatibility Strategies
    slide10 = create_base_slide(prs, blank_layout, "Compatibility Strategy",
                                "하위 및 상위 호환성 (Backward & Forward Compatibility) 기법",
                                "필드 추가, 파라미터 확장 시 바이너리 깨짐을 원천 방지하는 4대 설계 패턴", 10)
    
    add_feature_card(slide10, 0.8, 1.8, 5.7, 2.35, "Strategy 1: Additive-Only Evolution", "1. 가산적(Additive) 필드 확장 원칙", [
        "기존 필드의 순서, 크기, 의미는 절대 수정하거나 삭제하지 않음",
        "새로운 파라미터는 반드시 구조체 맨 끝에 추가",
        "새 필드는 기본값이 적용되도록 0(Null) 초기화 규칙 강제"
    ], C_CYAN)

    add_feature_card(slide10, 6.83, 1.8, 5.7, 2.35, "Strategy 2: Struct Size & Magic Check", "2. 구조체 크기(sizeof) 명시 패턴", [
        "struct Params { uint32_t struct_size; ... };",
        "엔진은 struct_size를 검사하여 클라이언트가 보낸 버전 식별",
        "sizeof(V1) 크기만 들어오면 신규 필드는 기본값으로 자동 채움"
    ], C_BLUE)

    add_feature_card(slide10, 0.8, 4.35, 5.7, 2.45, "Strategy 3: Reserved Padding Buffer", "3. 미래 대비 예약 패딩(Reserved Fields)", [
        "구조체 선언 시 미리 32~64바이트의 char reserved[32] 확보",
        "사소한 플래그나 옵션 추가 시 구조체 전체 크기를 변경하지 않고 예약 영역에서 소모",
        "C-ABI 구조체 크기를 고정시켜 바이너리 호환성 영구 보존"
    ], C_EMERALD)

    add_feature_card(slide10, 6.83, 4.35, 5.7, 2.45, "Strategy 4: Feature Flags Negotiation", "4. 기능 플래그(Feature Flags) 비트마스크", [
        "uint64_t enabled_features 비트 플래그 필드 도입",
        "클라이언트가 자신이 이해하는 기능 비트만 활성화하여 전송",
        "엔진은 미지원 플래그 감지 시 오류 또는 소프트 폴백(Soft Fallback)"
    ], C_PURPLE)

    # SLIDE 11: Zero-Copy Data Compatibility across Versions
    slide11 = create_base_slide(prs, blank_layout, "Zero-Copy Versioning",
                                "대용량 메시 데이터 모델의 버전 호환성 유지 기법",
                                "수백만 폴리곤의 메모리 복사 없이 버퍼 레이아웃을 안전하게 진화시키는 메타데이터 디스크립터", 11)
    
    add_feature_card(slide11, 0.8, 1.8, 5.7, 4.95, "Buffer Descriptor Protocol", "버퍼 디스크립터 (Buffer Descriptor) 규격", [
        "데이터 자체와 메타데이터의 완전 분리:",
        "struct GeometryBufferDescriptor {",
        "    uint32_t descriptor_version; // v1: Float32, v2: Float64...",
        "    uint32_t vertex_format;      // 0: XYZ, 1: XYZ_RGB, 2: XYZ_NORM",
        "    uint32_t memory_layout;      // 0: RowMajor, 1: ColMajor",
        "    uint32_t alignment;          // 64 (AVX-512 캐시 정렬)",
        "    uint64_t vertex_count;",
        "    uint64_t face_count;",
        "    uint64_t shared_memory_offset;",
        "};",
        "효과: 정규 버퍼의 물리적 포맷이 진화해도 디스크립터만 보고 어댑터가 제로카피 매핑 방식을 즉시 결정"
    ], C_CYAN)

    add_feature_card(slide11, 6.83, 1.8, 5.7, 4.95, "Zero-Copy Translation Pipeline", "무복사 변환 파이프라인 (In-Place Mapping)", [
        "구버전 클라이언트 (Float32 기대) vs 신버전 엔진 (Float64 제공):",
        "  • 최우선 순위: 포맷이 일치하면 100% Zero-Copy 매핑",
        "  • 불가피한 포맷 불일치 시:",
        "    - 공유 메모리 내 임시 변환 캐시 풀을 생성하여 비동기 전달",
        "    - 클라이언트에 경고(Warning: Precision Degradation) 발송",
        "  • 다음 메이저 버전 배포 전까지 통일된 정규 포맷 준수를 유도"
    ], C_BLUE)

    # SLIDE 12: Deprecation Policy & Lifecycle Management
    slide12 = create_base_slide(prs, blank_layout, "Lifecycle Management",
                                "API 라이프사이클 및 점진적 폐기(Deprecation) 거버넌스",
                                "API 추가부터 안전한 일몰(Sunset)까지의 4단계 수명주기 및 텔레메트리 관제", 12)
    
    col12 = 2.75
    gap12 = 0.244
    add_feature_card(slide12, 0.8 + 0*(col12+gap12), 1.8, col12, 3.4, "Stage 1: Active", "ACTIVE (표준)", [
        "현재 기본 권장 API",
        "모든 기능 및 최적화 지원",
        "버그 수정 및 기능 개선",
        "공식 문서 메인 게시"
    ], C_EMERALD)

    add_feature_card(slide12, 0.8 + 1*(col12+gap12), 1.8, col12, 3.4, "Stage 2: Deprecated", "DEPRECATED (경고)", [
        "차기 버전 대체 API 존재",
        "최소 6개월~1년 유예 기간",
        "호출 시 텔레메트리 경고",
        "신규 프로젝트 사용 금지",
        "기존 동작은 100% 유지"
    ], C_AMBER)

    add_feature_card(slide12, 0.8 + 2*(col12+gap12), 1.8, col12, 3.4, "Stage 3: Sunset", "SUNSET (일몰 공지)", [
        "폐기 일자 확정 공지",
        "보안/치명적 패치만 제공",
        "클라이언트에 마이그레이션 안내 팝업/로그 전달",
        "폐기 3개월 전 최종 통보"
    ], C_ROSE)

    add_feature_card(slide12, 0.8 + 3*(col12+gap12), 1.8, col12, 3.4, "Stage 4: Retired", "RETIRED (제거)", [
        "엔진 코드베이스에서 제거",
        "새 메이저 버전(X.0.0) 배포 시점에 완전 삭제",
        "호출 시 즉시 에러 반환",
        "레거시 부채 정리 완료"
    ], C_TEXT_DIM)

    add_feature_card(slide12, 0.8, 5.4, 11.733, 1.45, "Deprecation Warning Delivery", "클라이언트 대상 Deprecation 통보 메커니즘", [
        "C++ 컴파일 타임: [[deprecated(\"Use RemeshV2 instead. Sunset: 2027-01\")]] 속성 부여",
        "IPC 런타임: 응답 패킷 헤더의 warning_flags 비트 설정 및 대체 API 마이그레이션 가이드 URL 동봉"
    ], C_PURPLE)

    # SLIDE 13: Code Walkthrough - IPC Packet & Dispatcher
    slide13 = create_base_slide(prs, blank_layout, "Code Implementation 1",
                                "구체화 코드: Headless IPC 패킷 헤더 및 버전 라우터",
                                "C++20 기반의 패킷 정의 및 다중 버전 디스패치 라우터 핵심 구현", 13)
    
    add_feature_card(slide13, 0.8, 1.8, 5.7, 4.95, "Header Definition", "IpcProtocol.hpp 핵심 구조체", [
        "struct alignas(8) IpcHeader {",
        "    uint32_t magic = 0x4D455348;",
        "    uint16_t api_major; // 1, 2, 3",
        "    uint16_t api_minor; // 0, 1...",
        "    uint32_t command_id;",
        "    uint64_t payload_bytes;",
        "    uint64_t shm_handle;",
        "};",
        "// 버전 라우터 인터페이스",
        "class IApiVersionHandler {",
        "public:",
        "    virtual ~IApiVersionHandler() = default;",
        "    virtual ApiResponse Process(const IpcHeader& h, const uint8_t* payload) = 0;",
        "};"
    ], C_CYAN)

    add_feature_card(slide13, 6.83, 1.8, 5.7, 4.95, "Router Dispatch Logic", "VersionRouter::Dispatch() 라우팅 로직", [
        "ApiResponse VersionRouter::Dispatch(const IpcHeader& header, const uint8_t* payload) {",
        "    // 메이저 버전으로 핸들러 조회",
        "    auto it = handlers_.find(header.api_major);",
        "    if (it == handlers_.end()) {",
        "        return MakeError(ERR_UNSUPPORTED_VERSION, \"Version not supported\");",
        "    }",
        "    // 해당 버전 핸들러로 위임 실행",
        "    return it->second->Process(header, payload);",
        "}",
        "--- 핵심 원리 ---",
        "버전 번호에 따라 격리된 독립 핸들러가 호출되므로 버전 간 코드 간섭 0%"
    ], C_EMERALD)

    # SLIDE 14: Code Walkthrough - Stable C-ABI Evolution
    slide14 = create_base_slide(prs, blank_layout, "Code Implementation 2",
                                "구체화 코드: 버전별 C-ABI 인터페이스 진화 (v1 -> v2)",
                                "기존 v1 시그니처를 보존하면서 신규 기능을 안전하게 확장하는 실제 C-ABI 패턴", 14)
    
    add_feature_card(slide14, 0.8, 1.8, 5.7, 4.95, "Version 1 Specification", "mesh_api_v1.h (레거시 스펙)", [
        "typedef struct {",
        "    uint32_t struct_size; // sizeof(RemeshParams_v1)",
        "    double target_edge_length;",
        "    int32_t iterations;",
        "} RemeshParams_v1;",
        "",
        "// v1 API 함수",
        "EXPORT_API int32_t MeshEngine_Remesh_v1(",
        "    MeshHandle handle,",
        "    const RemeshParams_v1* params",
        ");"
    ], C_CYAN)

    add_feature_card(slide14, 6.83, 1.8, 5.7, 4.95, "Version 2 Evolution", "mesh_api_v2.h (확장 스펙)", [
        "typedef struct {",
        "    uint32_t struct_size; // sizeof(RemeshParams_v2)",
        "    double target_edge_length;",
        "    int32_t iterations;",
        "    // v2 신규 추가 필드 (끝에 추가)",
        "    double sharp_crease_angle; // 기본값: 30도",
        "    bool preserve_boundary;    // 기본값: true",
        "    uint32_t feature_flags;    // 미래 대비 플래그",
        "} RemeshParams_v2;",
        "",
        "// v2 API 함수 (v1과 별도 심볼로 공존)",
        "EXPORT_API int32_t MeshEngine_Remesh_v2(",
        "    MeshHandle handle,",
        "    const RemeshParams_v2* params",
        ");"
    ], C_EMERALD)

    # SLIDE 15: Automated CI/CD Guardrails & ABI Testing
    slide15 = create_base_slide(prs, blank_layout, "Quality Assurance",
                                "버전 파괴를 사전에 차단하는 자동화 CI/CD 가드레일",
                                "개발자의 실수로 인한 예기치 않은 하위 호환성 파괴를 컴파일/PR 단계에서 강제 검출", 15)
    
    add_feature_card(slide15, 0.8, 1.8, 3.75, 4.95, "Tool 1: ABI Checker", "abi-compliance-checker", [
        "도구: libabigail / abi-compliance-checker",
        "동작 원리:",
        "  • 릴리즈된 v1.0.0 DLL/SO와 신규 빌드 바이너리의 DWARF/PDB 디버그 심볼 비교",
        "  • 구조체 크기 변경, 가상함수 vtable 순서 변경, 매개변수 타입 변조 자동 감지",
        "  • Breaking change 발생 시 CI 빌드 즉시 실패 처리"
    ], C_CYAN)

    add_feature_card(slide15, 4.79, 1.8, 3.75, 4.95, "Tool 2: Schema Linter", "Schema Breaking Change Linter", [
        "도구: buf breaking / FlatBuffers schema validator",
        "동작 원리:",
        "  • Git PR 검사 시 이전 버전 .proto/.fbs 스키마 파일과 Diff 분석",
        "  • 기존 필드 ID 재사용, 필드 삭제, 타입 변경 등 비호환 변경 원천 차단",
        "  • 100% 안전한 필드 추가만 머지 승인"
    ], C_BLUE)

    add_feature_card(slide15, 8.78, 1.8, 3.75, 4.95, "Tool 3: Contract Matrix", "Contract Matrix 회귀 테스트", [
        "엔진-클라이언트 다중 버전 매트릭스 테스트:",
        "  • Engine V2.0 ↔ Client V1.0 패킷 전송 테스트",
        "  • Engine V2.0 ↔ Client V2.0 패킷 전송 테스트",
        "  • 모든 레거시 클라이언트 시나리오가 에러 없이 성공함을 매 빌드마다 자동 검증"
    ], C_EMERALD)

    # SLIDE 16: Implementation Roadmap
    slide16 = create_base_slide(prs, blank_layout, "Implementation Roadmap",
                                "버전 관리 시스템 구축 4단계 실행 로드맵",
                                "프로토콜 규격 동결부터 다중 버전 어댑터 및 CI 자동 검증 파이프라인 도입까지", 16)
    
    col16 = 2.75
    gap16 = 0.244
    add_feature_card(slide16, 0.8 + 0*(col16+gap16), 1.8, col16, 4.95, "Phase 1 (1~2주)", "Protocol Freeze", [
        "SemVer 2.0 거버넌스 수립",
        "IPC 패킷 헤더 (32B) 불변 규격 제정",
        "C-ABI 함수 테이블 템플릿 작성",
        "구조체 struct_size 헤더 강제 규칙화"
    ], C_CYAN)

    add_feature_card(slide16, 0.8 + 1*(col16+gap16), 1.8, col16, 4.95, "Phase 2 (3~4주)", "Router & Adapters", [
        "VersionRouter 코어 구현",
        "V1 어댑터 및 V2 어댑터 분리",
        "기본값 주입 및 파라미터 정규화",
        "핸드셰이크 프로토콜 연동"
    ], C_BLUE)

    add_feature_card(slide16, 0.8 + 2*(col16+gap16), 1.8, col16, 4.95, "Phase 3 (5~6주)", "Lifecycle & Telemetry", [
        "[[deprecated]] 속성 시스템 구축",
        "런타임 경고 패킷 전송 파이프라인",
        "클라이언트 버전별 호출 통계 수집",
        "일몰(Sunset) 관리 대시보드"
    ], C_PURPLE)

    add_feature_card(slide16, 0.8 + 3*(col16+gap16), 1.8, col16, 4.95, "Phase 4 (7~8주)", "Automated CI Guards", [
        "GitHub Actions / CI 파이프라인 연동",
        "abi-compliance-checker 연동",
        "스키마 breaking check 자동화",
        "다중 클라이언트 매트릭스 회귀 테스트"
    ], C_EMERALD)

    # SLIDE 17: Conclusion & Best Practices
    slide17 = create_base_slide(prs, blank_layout, "Conclusion",
                                "Headless API 버전 관리 성공을 위한 핵심 요약",
                                "기술적 엄격성과 아키텍처적 유연성을 결합한 완성형 거버넌스 체계", 17)
    
    add_feature_card(slide17, 0.8, 1.8, 3.75, 4.0, "Core Principle 1", "철저한 계층 격리", [
        "코어 알고리즘(UnifiedMesh)과 통신/버전 관리 계층을 완벽히 분리하여, 버전 파편화가 기하학적 연산 로직을 오염시키지 않도록 보호합니다."
    ], C_CYAN)

    add_feature_card(slide17, 4.79, 1.8, 3.75, 4.0, "Core Principle 2", "Stable C-ABI & SemVer", [
        "C++ ABI의 취약성을 극복하는 C-ABI Barrier 및 SemVer 규칙을 준수하여, 컴파일러나 런타임 종속성 없이 모든 클라이언트와 영구 호환성을 유지합니다."
    ], C_BLUE)

    add_feature_card(slide17, 8.78, 1.8, 3.75, 4.0, "Core Principle 3", "버전 라우터 & 지연 폐기", [
        "단일 엔진에서 다중 버전을 동시에 디스패치하고, 6개월 이상의 충분한 유예기간과 텔레메트리 경고를 통해 클라이언트의 자연스러운 마이그레이션을 보장합니다."
    ], C_EMERALD)

    glow17 = slide17.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(6.0), Inches(11.733), Inches(0.9))
    set_shape_flat(glow17, C_CARD_ALT, C_BORDER_ACCENT, 1)
    
    tb17 = slide17.shapes.add_textbox(Inches(1.0), Inches(6.05), Inches(11.333), Inches(0.8))
    tf17 = tb17.text_frame
    tf17.word_wrap = True
    p17 = tf17.paragraphs[0]
    p17.text = "🎯 결론: 본 API 버전 관리 아키텍처를 도입함으로써, Headless 메시 프로세싱 엔진은 아무리 빈번한 알고리즘 업데이트가 발생하더라도 기존 클라이언트 서비스의 중단 없이 영구적으로 신뢰할 수 있는 산업용 플랫폼으로 발전할 수 있습니다."
    p17.font.name = FONT_HEADING
    p17.font.size = Pt(11)
    p17.font.bold = True
    p17.font.color.rgb = C_WHITE

    out_path = r"d:\engine\Headless_API_Versioning_Strategy.pptx"
    prs.save(out_path)
    print(f"Presentation saved successfully to: {out_path}")
    
    artifact_dir = r"C:\Users\cadca\.gemini\antigravity-ide\brain\d6e8f226-e4ca-4d27-a4e8-f485fc4a50d1"
    artifact_pptx = os.path.join(artifact_dir, "Headless_API_Versioning_Strategy.pptx")
    prs.save(artifact_pptx)
    print(f"Copy saved to artifact directory: {artifact_pptx}")

if __name__ == "__main__":
    build_presentation()
