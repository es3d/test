#include "mesh_engine/UnifiedMesh.hpp"
#include <iostream>
#include <vector>
#include <chrono>

using namespace mesh_engine;

int main() {
    std::cout << "=========================================================\n";
    std::cout << "  UnifiedMesh Architecture & Concrete Realization Demo   \n";
    std::cout << "  Zero-Copy Direct Binding & Dual-Representation Core    \n";
    std::cout << "=========================================================\n\n";

    // 1. 샘플 3D 큐브 메시 (8 Vertices, 12 Triangles)
    std::vector<double> vertices = {
        -1.0, -1.0, -1.0,  // 0
         1.0, -1.0, -1.0,  // 1
         1.0,  1.0, -1.0,  // 2
        -1.0,  1.0, -1.0,  // 3
        -1.0, -1.0,  1.0,  // 4
         1.0, -1.0,  1.0,  // 5
         1.0,  1.0,  1.0,  // 6
        -1.0,  1.0,  1.0   // 7
    };

    std::vector<int32_t> faces = {
        0, 1, 2,  0, 2, 3,  // 전면
        4, 6, 5,  4, 7, 6,  // 후면
        0, 4, 5,  0, 5, 1,  // 하면
        2, 6, 7,  2, 7, 3,  // 상면
        0, 3, 7,  0, 7, 4,  // 좌측면
        1, 5, 6,  1, 6, 2   // 우측면
    };

    // 2. UnifiedMesh 생성 및 초기화
    std::cout << ">>> [Step 1] Initializing UnifiedMesh with 8 vertices and 12 triangles...\n";
    UnifiedMesh mesh;
    mesh.Initialize(vertices.data(), 8, faces.data(), 12);

    // 3. Zero-Copy VTK 객체 획득
    std::cout << ">>> [Step 2] Binding to VTK Pipeline via Zero-Copy Adapter...\n";
    auto poly_data = mesh.GetVtkPolyData();

    // 4. Zero-Copy 메모리 주소 일치 검증
    mesh.PrintMemoryDiagnostic();

    // 5. 실시간 기하 변형 (Geometry-Only Mutation: 60 FPS Path)
    std::cout << ">>> [Step 3] Simulating Real-Time Sculpting / ARAP Deformation...\n";
    std::cout << "    - Displacing Vertex 0 by (+0.5, +0.2, -0.1) in-place...\n";

    auto start_time = std::chrono::high_resolution_clock::now();
    mesh.DisplaceVertex(0, 0.5, 0.2, -0.1);
    auto end_time = std::chrono::high_resolution_clock::now();

    auto elapsed_us = std::chrono::duration_cast<std::chrono::nanoseconds>(end_time - start_time).count();
    std::cout << "    - In-place mutation elapsed time: " << elapsed_us / 1000.0 << " us (micro-seconds)\n";
    std::cout << "    - State after displacement: " << ToString(mesh.GetDirtyState()) << "\n";

    // VTK 파이프라인에서 정점 0의 새로운 좌표 직접 확인
    double* vtk_ptr = static_cast<double*>(poly_data->GetPoints()->GetVoidPointer(0));
    std::cout << "    - VTK Vertex 0 New Pos: (" << vtk_ptr[0] << ", " << vtk_ptr[1] << ", " << vtk_ptr[2] << ")\n";
    std::cout << "    >> ZERO MEMORY COPY CONFIRMED: VTK reflected new coordinates instantly! <<\n\n";

    // 6. Half-Edge 기반 O(1) 위상 질의 및 변이 (Topology Mutation Path)
    std::cout << ">>> [Step 4] Accessing Half-Edge Topology View & 1-Ring Query...\n";
    auto he_mesh = mesh.GetHalfEdgeMesh();
    auto neighbors = he_mesh->Get1RingNeighbors(0);
    std::cout << "    - Vertex 0's 1-Ring Neighbor Count: " << neighbors.size() << " vertices [ ";
    for (auto n : neighbors) std::cout << n << " ";
    std::cout << "]\n";

    std::cout << "\n>>> [Step 5] Performing Local Edge Flip on Edge 0...\n";
    bool flip_ok = mesh.FlipEdge(0);
    std::cout << "    - Flip Result: " << (flip_ok ? "SUCCESS" : "FAILED") << "\n";
    std::cout << "    - Dirty State after Flip: " << ToString(mesh.GetDirtyState()) << "\n";

    // 7. 파이프라인 최종 동기화
    std::cout << "\n>>> [Step 6] Synchronizing Complete Pipeline (Lazy Sync)...\n";
    mesh.Synchronize();
    std::cout << "    - Final State: " << ToString(mesh.GetDirtyState()) << " (All views unified!)\n\n";

    mesh.PrintMemoryDiagnostic();

    std::cout << "=========================================================\n";
    std::cout << "  UnifiedMesh Demonstration Completed Successfully!      \n";
    std::cout << "=========================================================\n";
    return 0;
}
